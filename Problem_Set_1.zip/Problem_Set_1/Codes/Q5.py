import numpy as np

mu=47
sigma=10
N=25
Exp = np.random.normal(mu,sigma,N)
print(Exp)

Exp_mean = np.mean(Exp)
print(Exp_mean)

Est_AV = list()
for i in range(100):
	Exp = np.random.normal(mu,sigma,N)
	Exp_mean = np.mean(Exp)
	Est_AV.append(Exp_mean)

MU = np.mean(Est_AV)
SIGMA = np.var(Est_AV)
print(MU)
print(SIGMA)
