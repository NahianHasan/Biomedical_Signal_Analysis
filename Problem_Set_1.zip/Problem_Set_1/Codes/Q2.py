import scipy.io
import matplotlib.pyplot as plt
from scipy.fft import fft, fftfreq, fftshift
import numpy as np

S=scipy.io.loadmat('mysterysignal.mat')
X = S['x'][0]
fs = 22050
length_t=len(X)/fs
print(length_t)
'''
Length of time is 2 seconds
'''
t=np.arange(0,length_t*1000)
ts=round(200*fs/1000)
print(ts)
x200 = X[0:ts]
plt.figure()
plt.plot(np.arange(ts),x200)
plt.show()

f = np.fft.fftfreq(len(X),d=1/fs)
Xf2 = fft(x200,n=len(f))
plt.figure()
plt.plot(f,np.abs(Xf2))
plt.title('Frequency Spectrum of X200')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Spectrum Magnitude, |Xf2|')
plt.show()
#plt.savefig('Q2_c.png')
sinusoid_freq = [100,169,222,700]
sinusoid_ampl = [267.2,411.87,840.285,282]
'''
Amplitude at each frquency is signifiicantly reduced
frequency resolution is fs/N; N=number of data points
'''
