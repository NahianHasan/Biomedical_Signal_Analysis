import scipy.io
import matplotlib.pyplot as plt
from scipy.fft import fft, fftfreq, fftshift
import numpy as np

S=scipy.io.loadmat('mysterysignal.mat')
X = S['x'][0]
'''
print(X[0])
plt.plot(X)
plt.show()
'''

############ Q1(a) ##############
Xf = fft(X)
fs = 22050
f = np.fft.fftfreq(len(X),d=1/fs)  # Frequency axis in Hz
plt.plot(f,np.abs(Xf))

plt.title('Frequency Spectrum of X')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Spectrum Magnitude, |X(f)|')
plt.show()
#plt.savefig('Q1_a.png')



############ Q1(b,c) ##############
sinusoid_freq = [100,169,221,223,700]
sinusoid_ampl = [2850,4418,5799,5666.6,2897.5]
for i in range(0,4):
	print(sinusoid_ampl[i]/sinusoid_ampl[4])

#relative amplitude w.r.t. highest frequency amplitude
'''
0.9836065573770492
1.524762726488352
2.0013805004314063
1.9556859361518553
'''

############ Q1(d) ##############
threshold = 0.5*min(sinusoid_ampl)
phi = np.angle(Xf)
phi[np.abs(Xf) < threshold] = 0
plt.figure()
plt.scatter(f,phi)
plt.title('Phase Angle Representation of Signal after thresholding')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Angle(Xf) in radians')
#plt.show()
plt.savefig('Q1_d.png')

sinusoid_angl = [-0.060059,-0.105145,-0.13878,-0.14067,-0.42363]
