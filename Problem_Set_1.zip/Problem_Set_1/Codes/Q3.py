import scipy.io
import matplotlib.pyplot as plt
from scipy.fft import fft, fftfreq, fftshift,ifft
import numpy as np
from IPython.display import Audio
import sounddevice as sd

S=scipy.io.loadmat('stalbans.mat')
print(S)
'''
print(X[0])
plt.plot(X)
plt.show()
'''
fs = S['fs'][0][0]
h = S['h'][0]
x = S['x'][0]
print(fs)
print(h)
print(x)
'''
#Audio(data=x, rate=fs)
sd.play(h, fs)
status = sd.wait()  # Wait until file is done playing
sd.play(x, fs)
status = sd.wait()  # Wait until file is done playing
'''
#Convolution
Y = np.convolve(x,h)
'''
sd.play(Y, fs)
status = sd.wait()  # Wait until file is done playing
'''
print(h.shape)
print(len(x))
X = np.pad(x,(0,len(h)-len(x)),mode='constant')
print(X.shape)

Xf = fft(X)
hf = fft(h)
Yf = Xf*hf
Yifft = ifft(Yf)
sd.play(np.abs(Yifft), fs)
status = sd.wait()  # Wait until file is done playing
'''
Due to padding with zeros, the frequency resolution changed, hence inverse fft does not produce the same result as expected. Since we are incresing
the sample point, the frequency resolution is being increased. hence, ifft will result in some artifact noise along with the original sound
'''
