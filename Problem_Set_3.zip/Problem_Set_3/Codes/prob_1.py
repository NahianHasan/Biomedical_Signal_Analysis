import numpy as np
from scipy import signal
import math
import matplotlib.pyplot as plt
from scipy import linalg
import scipy.io

def ar1(a,Nsamps,Nexamples):
	variances = np.zeros((Nexamples,1))
	x = np.zeros((Nexamples,Nsamps))
	for it in range(Nexamples):
		w=np.random.randn(1,Nsamps)[0]
		x[it,0]=w[0]
		for i in range(1,len(w)):
			x[it,i] = a*x[it,i-1] + w[i]
		variances[it] = np.var(x[it,:])

	x = x / np.sqrt(variances)
	return x,w,variances

def plot_result(x,w,variances,name):
	for i in range(x.shape[0]):
		plt.plot(x[i,:])
	plt.xlabel('Samples')
	plt.ylabel('x(t)')
	plt.xlim(1001,2000)
	plt.ylim((-5,5))
	#plt.show()
	plt.savefig('prob_1_b'+name+'.png')
	plt.figure()
	plt.plot(w)
	plt.xlim(1001,2000)
	plt.ylim((-5,5))
	plt.xlabel('Samples')
	plt.ylabel('w(t)')
	plt.savefig('prob_1_b_2'+name+'.png')

	print('Variances = ',variances)
	print('Mean Variance = ',np.mean(variances))
	plt.figure()
	plt.plot(variances)
	plt.plot([0,10],[np.mean(variances),np.mean(variances)])
	plt.xlabel('Sample Example')
	plt.ylabel('Across-Sample Variance of each example')
	plt.savefig('prob_1_c'+name+'.png')

def autocorr(a,var_w):
	Rxx = []
	for tau in range(0,2000):
		Rxx.append(math.pow(a,tau)*(var_w/(1-math.pow(a,2))))
	return Rxx

def Main():
	x,w,variances = ar1(0.99,2000,10)
	plot_result(x,w,variances,'')
	x,w,variances = ar1(0.999,2000,10)
	plot_result(x,w,variances,'_1e')
	Rxx_1 = autocorr(0.99,1)
	Rxx_2 = autocorr(0.999,1)
	Rxx_3 = autocorr(0,1)
	plt.figure()
	plt.plot(Rxx_3)
	plt.plot(Rxx_1)
	plt.plot(Rxx_2)
	plt.xlabel('sample lag')
	plt.ylabel('correlation function Rxx')
	plt.legend(['a=0','a=0.99','a=0.999'])
	plt.savefig('prob_1_e.png')

	###### part f ################
	Max_count = 0
	x,w,variances = ar1(0.99,2000,1000)
	for i in range(0,x.shape[0]):
		if np.max(x[i,:]) >= 4:
			Max_count += 1
	print('Max count = ',Max_count)
Main()
