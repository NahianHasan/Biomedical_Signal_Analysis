import numpy as np
import math
from scipy.special import comb
import matplotlib.pyplot as plt
from scipy import stats
from scipy.stats import binom

def calc_prob(n,x):
	P = comb(n,x) * math.pow(1/3,x) * math.pow(2/3,(n-x))
	return P

def Main():
	P = []
	n = 50
	cdf = 0
	null_list = []
	p_test = 0.05
	point_count = 0
	point_track_p = 0.05
	for x in range(1,50):
		val = calc_prob(n,x)
		#print(x,' -- ',val)
		P1 = binom.cdf(x,n,1/3)
		P.append(val)
		cdf += val
		p_val = 1-cdf
		if p_val < p_test:
			null_list.append(x)

		if p_val > point_track_p:
			point_count = point_count
		else:
			point_count += 1
			point_track_p = point_track_p/10

		print('x = ',x,' p_val = ',p_val,' P_track = ',point_track_p,' points = ',point_count)





	plt.plot(P)
	plt.xlabel('x')
	plt.ylabel('Probability, P(x)')
	plt.savefig('prob_2_b.png')
	#print('\n\n',np.mean(np.array(P)))
	#print(P.index(np.max(np.array(P))))

	print('Minimum Number of questioins correct for rejecting Null-Hypothesis = ',min(null_list))


Main()
