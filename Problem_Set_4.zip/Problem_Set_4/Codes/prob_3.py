import numpy as np
import os
import matplotlib.pyplot as plt
from scipy import signal
import tfr

if not os.path.exists('./Results'):
	os.makedirs('./Results')


def plot_spectrograms(t,freqs,psd,name,title):
	plt.figure()
	plt.pcolormesh(t, freqs, 10 * np.log10(psd.squeeze()), cmap='RdYlBu_r', shading='auto')
	plt.xlabel('Time (s)',fontsize=15)
	plt.ylabel('Frequency (Hz)',fontsize=15)
	plt.title(title,fontsize=15)
	plt.xticks(fontsize=13)
	plt.yticks(fontsize=13)
	plt.colorbar()
	plt.tight_layout()
	plt.savefig(name+'.png')

######################### part a ############################
fs = 10000
t = np.arange(0,1,1/fs)
print(t.shape)
initial_phase = 0
phase = lambda x: np.cos(2*np.pi*(100*x+(400/3)*np.power(x,3))+initial_phase)
phase_val  = np.vectorize(phase)
phi = phase_val(t)
e = np.random.normal(0.0,0.5,fs)
phi = phi+e
print(phi.shape)

plt.figure()
plt.plot(t,phi)
plt.title('Chirp Signal',fontsize=15)
plt.xlabel('Time (s)',fontsize=15)
plt.ylabel('Amplitude',fontsize=15)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
#plt.show()
plt.savefig('./Results/prob_3_a.png')

######################### part b ############################
#Define slepian tappers
NW = 4
Kmax = 4#Number of slepian tappers.
# Return concentrations too using return_ratios=True
wins, concentrations = signal.windows.dpss(fs, NW, Kmax=Kmax, return_ratios=True)
S_mt = 0
for ktap in range(Kmax):
	f_mt, S_temp = signal.periodogram(phi, window=wins[ktap, :], fs=fs)
	S_mt += S_temp
S_mt /= Kmax
plt.figure()
plt.plot(wins.T)
plt.title('Sleppian tappers',fontsize=15)
plt.xlabel('Sample',fontsize=15)
plt.ylabel('Amplitude',fontsize=15)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.tight_layout()
plt.savefig('./Results/prob_3_b_1.png')
plt.figure()
plt.plot(concentrations)
plt.ylim([0, 1.1])
plt.title('Sleppian tappers concentration',fontsize=15)
plt.xlabel('#Sleppian Windows',fontsize=15)
plt.ylabel('Concentration ratio',fontsize=15)
plt.xticks(np.arange(0,concentrations.shape[0]),[str(i) for i in range(1,concentrations.shape[0]+1)],fontsize=13)
plt.yticks(fontsize=13)
plt.tight_layout()
plt.savefig('./Results/prob_3_b_2.png')

# Tapered periodogram
f_periodogram, S_periodogram = signal.periodogram(phi, window='hann', fs=fs)
f, S_welch = signal.welch(phi, window='hann', nperseg=fs/2, fs=fs)
plt.figure()
plt.plot(f_periodogram[0:1000], (10*np.log10(S_periodogram))[0:1000], '--',label='Hann Window')
plt.plot(f_mt[0:1000], (10*np.log10(S_mt))[0:1000],label='DPSS (4)')
#plt.plot((10*np.log10(S_welch))[0:1000],label='Welch')
plt.xlabel('Frequency (Hz)',fontsize=15)
plt.ylabel('S(f) in dB',fontsize=15)
plt.legend()
plt.title('Spectrum Estimation (Original Signal)',fontsize=15)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.tight_layout()
plt.savefig('./Results/prob_3_b_3.png')


######################### part c ############################
phi_inv = phase_val(-t) + e
S_mt = 0
for ktap in range(Kmax):
	f_mt, S_temp = signal.periodogram(phi_inv, window=wins[ktap, :], fs=fs)
	S_mt += S_temp
S_mt /= Kmax
# Tapered periodogram
f_periodogram, S_periodogram = signal.periodogram(phi_inv, window='hann', fs=fs)
f, S_welch = signal.welch(phi_inv, window='hann', nperseg=fs/2, fs=fs)
plt.figure()
plt.plot(f_periodogram[0:1000], (10*np.log10(S_periodogram))[0:1000], '--',label='Hann Window')
plt.plot(f_mt[0:1000], (10*np.log10(S_mt))[0:1000],label='DPSS (4)')
#plt.plot((10*np.log10(S_welch))[0:1000],label='Welch')
plt.xlabel('Frequency (Hz)',fontsize=15)
plt.ylabel('S(f) in dB',fontsize=15)
plt.legend()
plt.title('Spectrum Estimation (Inverse Signal)',fontsize=15)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.tight_layout()
plt.savefig('./Results/prob_3_c.png')


######################### part d ############################
freqs = np.arange(50, 800, 5)
print(freqs)
n_cycles = 0.1 * freqs  # 100 ms windows
time_bandwidth = 2#The number of good tapers (low-bias) is chosen automatically based on this to equal floor(time_bandwidth - 1).
psd, t = tfr.tfr_multitaper(phi[None, None, :], fs, frequencies=freqs, time_bandwidth=time_bandwidth, n_cycles=n_cycles)
plot_spectrograms(t,freqs,psd,'./Results/prob_3_d_1','Spectrogram (Original Signal - '+str(time_bandwidth-1)+' tappers)')
psd, t = tfr.tfr_multitaper(phi_inv[None, None, :], fs, frequencies=freqs, time_bandwidth=time_bandwidth, n_cycles=n_cycles)
plot_spectrograms(t,freqs,psd,'./Results/prob_3_d_2','Spectrogram (Inverse Signal - '+str(time_bandwidth-1)+' tappers)')


######################### part e ############################
freqs = np.arange(50, 800, 5)
n_cycles = 0.1 * freqs  # 100 ms windows
time_bandwidth = 5#The number of good tapers (low-bias) is chosen automatically based on this to equal floor(time_bandwidth - 1).
psd, t = tfr.tfr_multitaper(phi[None, None, :], fs, frequencies=freqs, time_bandwidth=time_bandwidth, n_cycles=n_cycles)
plot_spectrograms(t,freqs,psd,'./Results/prob_3_e_1','Spectrogram (Original Signal - '+str(time_bandwidth-1)+' tappers)')
psd, t = tfr.tfr_multitaper(phi_inv[None, None, :], fs, frequencies=freqs, time_bandwidth=time_bandwidth, n_cycles=n_cycles)
plot_spectrograms(t,freqs,psd,'./Results/prob_3_e_2','Spectrogram (Inverse Signal - '+str(time_bandwidth-1)+' tappers)')
