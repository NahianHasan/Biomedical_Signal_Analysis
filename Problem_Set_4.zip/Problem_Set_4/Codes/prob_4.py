import numpy as np
import os
import matplotlib.pyplot as plt
from scipy import signal
import tfr
import scipy.io



if not os.path.exists('./Results'):
	os.makedirs('./Results')

def plot_spectrograms(t,freqs,psd,name,title):
	plt.figure()
	plt.pcolormesh(t, freqs, psd.squeeze(), cmap='RdYlBu_r', shading='auto')
	plt.xlabel('Time (s)',fontsize=15)
	plt.ylabel('Frequency (Hz)',fontsize=15)
	plt.title(title,fontsize=15)
	plt.xticks(fontsize=13)
	plt.yticks(fontsize=13)
	plt.colorbar()
	plt.savefig(name+'.png')

S = scipy.io.loadmat('speech.mat')
print(S.keys())
ba = S['ba'].squeeze()
da = S['da'].squeeze()
fs = S['fs'].squeeze()

print(ba.shape)
print(da.shape)
print(fs)

#freqs = np.logspace(32, 2048, num=10, endpoint=True, base=8)
freqs = np.arange(32, 2048,np.power(2,(1/20)))
print(freqs)
n_cycles = 9
time_bandwidth = 2
psd, t = tfr.tfr_multitaper(ba[None, None, :], fs, frequencies=freqs, time_bandwidth=time_bandwidth, n_cycles=n_cycles)
plot_spectrograms(t,freqs,psd,'./Results/prob_4_a_1','Spectrogram (ba Signal - '+str(time_bandwidth-1)+' tappers)')
psd, t = tfr.tfr_multitaper(da[None, None, :], fs, frequencies=freqs, time_bandwidth=time_bandwidth, n_cycles=n_cycles)
plot_spectrograms(t,freqs,psd,'./Results/prob_4_a_2','Spectrogram (da Signal - '+str(time_bandwidth-1)+' tappers)')
