import numpy as np
import os,math
import matplotlib.pyplot as plt
from scipy import signal
import tfr
import scipy.io
import pywt
from IPython.display import Audio
import sounddevice as sd
import time

if not os.path.exists('./Results'):
	os.makedirs('./Results')

S = scipy.io.loadmat('speech.mat')
print(S.keys())
ba = S['ba'].squeeze()
da = S['da'].squeeze()
fs = S['fs'].squeeze()

print('ba shape = ',ba.shape)
print('da shape = ',da.shape)
print('fs = ',fs)


################# Part a #########################################
coeffs_ba = pywt.wavedec(ba,wavelet='coif3', level=5)
arr, slices = pywt.coeffs_to_array(coeffs_ba)
ind = np.argsort(-np.abs(arr))#sorting in descending manner and get the corresponding indexes
ind = ind[math.floor(1/3*len(arr)):]#select the lowest 66% of the coefficent's indices
arr[ind] = 0#set the coefficients corresponding to those lowest indices to zero
# Convert back to wavedec/waverec format
coeffs_compressed = pywt.array_to_coeffs(arr, slices, output_format='wavedec')
compressed = pywt.waverec(coeffs_compressed, wavelet='coif3')
sd.play(compressed, fs)
status = sd.wait()


coeffs_da = pywt.wavedec(da,wavelet='coif3', level=5)
arr, slices = pywt.coeffs_to_array(coeffs_da)
ind = np.argsort(-np.abs(arr))#sorting in descending manner and get the corresponding indexes
ind = ind[math.floor(1/3*len(arr)):]#select the lowest 66% of the coefficent's indices
arr[ind] = 0#set the coefficients corresponding to those lowest indices to zero
# Convert back to wavedec/waverec format
coeffs_compressed = pywt.array_to_coeffs(arr, slices, output_format='wavedec')
compressed = pywt.waverec(coeffs_compressed, wavelet='coif3')
sd.play(compressed, fs)
status = sd.wait()



################# Part b #########################################
coeffs_da = pywt.wavedec(da,wavelet='coif3', level=5)
arr, slices = pywt.coeffs_to_array(coeffs_da)

for i in range(21,0,-2):
	arr_1 = arr
	ind = np.argsort(-np.abs(arr_1))#sorting in descending manner and get the corresponding indexes
	ind = ind[math.floor(i/100*len(arr_1)):]#select the lowest 66% of the coefficent's indices
	arr_1[ind] = 0#set the coefficients corresponding to those lowest indices to zero
	# Convert back to wavedec/waverec format
	coeffs_compressed = pywt.array_to_coeffs(arr_1, slices, output_format='wavedec')
	compressed = pywt.waverec(coeffs_compressed, wavelet='coif3')
	print(i)
	sd.play(da, fs)
	status = sd.wait()
	time.sleep(1)
	sd.play(compressed, fs)
	status = sd.wait()
	time.sleep(2)

#The compression seems articulated after 86-84% compressioin, But starting from 90% compression and more, the signal starts degrading, and over 93% compression, it is quite impossible to recognize the signal



################# Part c #########################################
coeffs_da = pywt.wavedec(da,wavelet='coif3', level=5)
arr_da, slices_da = pywt.coeffs_to_array(coeffs_da)
coeffs_ba = pywt.wavedec(ba,wavelet='coif3', level=5)
arr_ba, slices_ba = pywt.coeffs_to_array(coeffs_ba)

for i in range(21,0,-2):
	arr_1 = arr_da
	ind = np.argsort(-np.abs(arr_1))#sorting in descending manner and get the corresponding indexes
	ind = ind[math.floor(i/100*len(arr_1)):]#select the lowest 66% of the coefficent's indices
	arr_1[ind] = 0#set the coefficients corresponding to those lowest indices to zero
	# Convert back to wavedec/waverec format
	coeffs_compressed = pywt.array_to_coeffs(arr_1, slices_da, output_format='wavedec')
	compressed_da = pywt.waverec(coeffs_compressed, wavelet='coif3')

	arr_1 = arr_ba
	ind = np.argsort(-np.abs(arr_1))#sorting in descending manner and get the corresponding indexes
	ind = ind[math.floor(i/100*len(arr_1)):]#select the lowest 66% of the coefficent's indices
	arr_1[ind] = 0#set the coefficients corresponding to those lowest indices to zero
	# Convert back to wavedec/waverec format
	coeffs_compressed = pywt.array_to_coeffs(arr_1, slices_ba, output_format='wavedec')
	compressed_ba = pywt.waverec(coeffs_compressed, wavelet='coif3')


	print(i)
	sd.play(compressed_ba, fs)
	status = sd.wait()
	time.sleep(1)
	sd.play(compressed_da, fs)
	status = sd.wait()
	time.sleep(2)

#At or over 92-93% compression, it becomes impossible to distinguish between two signals
