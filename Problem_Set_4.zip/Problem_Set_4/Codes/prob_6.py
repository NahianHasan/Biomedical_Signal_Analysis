import numpy as np
import os,math
import matplotlib.pyplot as plt
from scipy import signal
from scipy import ndimage as img
import tfr
import scipy.io
import pywt
import time

S = scipy.io.loadmat('chestradiograph.mat')
print(S.keys())
image = S['I'].squeeze()
image = np.float64(image)/255.0
print(image.shape)

if not os.path.exists('./Results'):
	os.makedirs('./Results')

######################### Part a #################################
coeffs = pywt.wavedec2(image, wavelet='db2', level=6)
compression_ratio = 95#in percentage
# Convert to array -- easier for thresholding
arr, slices = pywt.coeffs_to_array(coeffs)
shape = arr.shape
arr = arr.flatten()#Flatten the image
ind = np.argsort(-arr)#sorting in descending manner and get the corresponding indexes
ind = ind[math.floor((100-compression_ratio)/100*len(arr)):]#select the lowest 95% of the coefficent's indices
arr[ind] = 0#set the coefficients corresponding to those lowest indices to zero
arr = np.reshape(arr,shape)

# Convert back to wavedec/waverec format
coeffs_compressed = pywt.array_to_coeffs(arr, slices, output_format='wavedec2')
compressed = pywt.waverec2(coeffs_compressed, wavelet='db2')
print(compressed.shape)
plt.figure(figsize=(10,10))
plt.subplot(121)
plt.imshow(image, cmap='gray', vmin=0, vmax=1)
plt.title('Original Image')
plt.colorbar(fraction=0.046, pad=0.04)
plt.subplot(122)
plt.imshow(compressed, cmap='gray', vmin=0, vmax=1)
plt.title('Compressed Image ({} % compression)'.format(compression_ratio))
plt.colorbar(fraction=0.046, pad=0.04)
plt.tight_layout()
plt.savefig('./Results/prob_6_a.png')


######################### Part b #################################
h = np.asarray([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])#sharpening filter
compressed_sharp = img.convolve(compressed, h, mode='nearest')
plt.figure(figsize=(10,10))
plt.subplot(131)
plt.imshow(image, cmap='gray', vmin=0, vmax=1)
plt.title('Original Image')
plt.colorbar(fraction=0.046, pad=0.04)
plt.subplot(132)
plt.imshow(compressed, cmap='gray', vmin=0, vmax=1)
plt.title('{}% Compressed Image'.format(compression_ratio))
plt.colorbar(fraction=0.046, pad=0.04)
plt.subplot(133)
plt.imshow(compressed_sharp, cmap='gray', vmin=0, vmax=1)
plt.title('Compressed_Sharpenned Image'.format(compression_ratio))
plt.colorbar(fraction=0.046, pad=0.04)
plt.tight_layout()
plt.savefig('./Results/prob_6_b.png')
