import os
import math
import numpy as np
import matplotlib.pyplot as plt
from scipy.fft import fft, fftfreq, fftshift

def F(t):
	return np.exp(-t/2)
'''
T0 = np.pi#period of the continuous signal
w = 2*np.pi/T0
N0 = 128#Number of samples per period
T = T0/N0#sampling interval
t = np.arange(0,T*N0,T)#Defined from 0 to T*(N0-1)
f = F(t)
f[0] = (F(T0)+F(t[0]))/2#To handle the point of discontinuity at t=pi

Dn = list()
n = np.arange(int(-N0/2),int(N0/2))
for i in n:#Defined from -N0/2 to (N0/2)-1
	E = np.array([np.exp(-1j*i*2*np.pi/N0*k) for k in range(0,N0)])
	D = np.matmul(f,E)
	Dn.append(D/N0)

Dn = np.array(Dn)
Dmag,Dang = np.absolute(Dn),np.angle(Dn,deg=True)#magnitude and angle

#Find trigonometric fourier coefficients
Cn = np.concatenate(([Dmag[int(np.floor(N0/2))]],2*Dmag[int(np.floor(N0/2))+1:]))
thetan = np.zeros(Cn.shape)

## Fourier Transform from scipy
Xf_scipy = fft(f)
fs_scipy = N0/T0
freq_axis_scipy = np.fft.fftfreq(len(f),d=1/fs_scipy)  # Frequency axis in Hz



plt.figure()
plt.subplot(231)
fp = np.concatenate((f,f,f,f))
tp = np.concatenate((t,t+T0,t+2*T0,t+3*T0))
plt.plot(tp,fp)
plt.title('Original periodic function',fontsize=13)
plt.xlabel('Time, t(s)',fontsize=13)
plt.ylabel('Amplitude',fontsize=13)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.subplot(232)
freq_axis = n*(w/(2*np.pi))
plt.stem(freq_axis,Dmag,label='Manual')
plt.scatter(freq_axis_scipy,np.absolute(Xf_scipy)/N0,c='r',label='Scipy')#In scipy the returned coefficients are in the form of Dn*N0. That is why divided by N0 to calculate the actual value of coefficient
plt.title('Amplitude of exponential Fourier coefficients',fontsize=13)
plt.xlabel('Frequency (Hz)',fontsize=13)
plt.ylabel('Amplitude',fontsize=13)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.legend()
plt.subplot(233)
plt.stem(freq_axis,Dang)
plt.title('Angle of exponential fourier coefficients',fontsize=13)
plt.xlabel('Frequency (Hz)',fontsize=13)
plt.ylabel('Angle (in degrees)',fontsize=13)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)

n_trig = np.arange(0,N0/2)
freq_axis = n_trig*(w/(2*np.pi))
plt.subplot(234)
plt.plot(tp,fp)
plt.title('Original periodic function',fontsize=13)
plt.xlabel('Time, t(s)',fontsize=13)
plt.ylabel('Amplitude',fontsize=13)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.subplot(235)
plt.stem(freq_axis,Cn)
plt.title('Amplitude of trigonometric Fourier coefficients',fontsize=13)
plt.xlabel('Frequency (Hz)',fontsize=13)
plt.ylabel('Amplitude',fontsize=13)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.subplot(236)
plt.stem(freq_axis,thetan)
plt.title('Angle of trigonometric fourier coefficients',fontsize=13)
plt.xlabel('Frequency (Hz)',fontsize=13)
plt.ylabel('Angle (in degrees)',fontsize=13)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
#plt.show()


# Reconstruction from exponential fourier spectrum
M=1000#how many coefficients to choose
recon_e = list()
for time in t:
	sum = 0
	count = 0
	ind=0
	while(count<M):
		sum += Dmag[ind]*np.exp(1j*ind*w*time)
		ind += 1
		if ind == len(Dn):
			ind=0
		count+=1
	sum += Dn[0]
	recon_e.append(sum)
recon_e = np.array(recon_e)
# Reconstruction from trigonometric fourier spectrum
recon_t = list()
for time in t:
	sum = 0
	count = 0
	ind=0
	while(count<M):
		sum += Cn[ind]*np.cos(ind*w*time+thetan[ind])
		ind += 1
		if ind == len(Cn):
			ind=0
		count+=1
	sum += Cn[0]
	recon_t.append(sum)
recon_t = np.array(recon_t)

plt.figure()
plt.subplot(131)
plt.plot(t,f)
plt.title('Original periodic function',fontsize=13)
plt.xlabel('Time, t(s)',fontsize=13)
plt.ylabel('Amplitude',fontsize=13)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.subplot(132)
plt.plot(t,recon_t)
plt.title('Reconstructed by trigonometric F.T.',fontsize=13)
plt.xlabel('Time, t(s)',fontsize=13)
plt.ylabel('Amplitude',fontsize=13)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.subplot(133)
plt.plot(t,recon_e)
plt.title('Reconstructed by exponential F.T.',fontsize=13)
plt.xlabel('Time, t(s)',fontsize=13)
plt.ylabel('Amplitude',fontsize=13)
plt.xticks(fontsize=13)
plt.yticks(fontsize=13)


plt.show()
'''

T0 = np.pi#period of the continuous signal
w = 2*np.pi/T0
N0 = 128#Number of samples per period
T = T0/N0#sampling interval
t = np.arange(0,T*N0,T)#Defined from 0 to T*(N0-1)
f = F(t)
f[0] = (F(T0)+F(t[0]))/2#To handle the point of discontinuity at t=pi


def custom_fft(f,N):
	#f = function values
	#N = N-point DFT
	F = list()
	F.append(list(range(0,N,2)))
	F.append(list(range(1,N,2)))
	res = N/2
	ind = 0
	F = np.array(F)
	while(res > 16):
		

		res = res/2
		ind += 1

custom_fft(f,N0)
